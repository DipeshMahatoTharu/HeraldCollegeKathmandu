def welcome():
    """
    Prints a welcome message for the Caesar Cipher program.
    """
    print("Welcome to the Caesar Cipher")
    print("This program encrypts and decrypts text using Caesar Cipher.")

def encrypt(message, shift):
    """
    Encrypts a given message using the Caesar Cipher technique.
    """
    result = ""
    for char in message:
        if char.isalpha():
            if char.islower():
                result += chr((ord(char) - ord('a' ) + shift) % 26 + ord('a'))
            else:
                result += chr((ord(char) - ord('A' ) + shift) % 26 + ord('A'))
        else:
            result += char
    return result.upper()

def decrypt(message, shift):
    """
    Decrypts a given message using the Caesar Cipher technique.
    """
    return encrypt(message, -shift)

def is_file(filename):
    """
    Checks if a file with the given filename exists.
    """
    try:
        with open(filename, 'r') as file:
            return True
    except FileNotFoundError:
        return False

def write_messages(messages):
    """
    Writes a list of messages to a file named 'results.txt'.
    """
    with open('results.txt', 'w') as file:
        for message in messages:
            file.write(message + '\n')

def process_file(filename, response, shift):
    """
    Reads a file line by line, encrypts or decrypts each line based on the response,
    and returns a list of processed messages.
    """
    messages = []
    print(f"Processing file: {filename}")  
    with open(filename, 'r') as file:
        for line in file:
            line = line.rstrip('\n')  
            if response == 'e':
                messages.append(encrypt(line, shift))  
            else:
                messages.append(decrypt(line, shift))  
    return messages  

def message_or_file():
    """
    Asks the user whether they want to encrypt or decrypt
    and whether they want to input a message or read from a file.
    """
    while True:
        response = input("Would you like to encrypt (e) or decrypt (d): ").lower()

        if response not in ['e', 'd']:
            print("Invalid response")
            continue

        source = input("Would you like to read from a file (f) or the console (c)? ").lower()

        if source == 'f':
            filename = input("Enter a filename: ")
            if is_file(filename):
                return response, None, filename
            else:
                print("Invalid Filename")
        elif source == 'c':
            message = input("What message would you like to {} : ".format("encrypt" if response == 'e' else "decrypt"))
            return response, message.upper(), None
        else:
            print("Invalid input. Please enter 'f' for file or 'c' for console.")

def main():
    """
    The main function that orchestrates the execution of the program.
    Repeatedly asks the user for input, processes messages, writes results to a file,
    and allows the user to repeat the process or exit.
    """
    welcome()
    while True:
        response, message, filename = message_or_file()
        shift = int(input("Enter shift number: "))
        if filename:
            messages = process_file(filename, response, shift)
        else:
            messages = [encrypt(message, shift)] if response == 'e' else [decrypt(message, shift)]
        write_messages(messages)

        # Display the output in the terminal
        print("Output:")
        for result in messages:
            print(result)

        repeat = input("Encrypt or decrypt another message? (y/n): ").lower()
        while repeat not in ['y', 'n']:
            repeat = input("Invalid input. Encrypt or decrypt another message? (y/n): ").lower()
        if repeat == 'n':
            print("Thanks for using the program, goodbye!")
            break

if __name__ == "__main__":
    main()
