# Student name : Dipesh Mahato Tharu
#Student ID :2408059


from noughtsandcrosses_2408059 import welcome, menu, play_game, save_score, load_scores, display_leaderboard

def main():
    board = [['1', '2', '3'], ['4', '5', '6'], ['7', '8', '9']]
    total_score = 0

    welcome(board)

    while True:
        choice = menu()
        if choice == '1':
            score = play_game(board)
            total_score += score
            print('Your current score is:', total_score)
        elif choice == '2':
            save_score(total_score)
        elif choice == '3':
            leader_board = load_scores()
            display_leaderboard(leader_board)
        elif choice == 'q':
            print('Thank you for playing the "Unbeatable Noughts and Crosses" game.')
            print('Goodbye')
            break

if __name__ == '__main__':
    main()
